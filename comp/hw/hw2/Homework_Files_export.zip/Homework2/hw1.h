
#include <limits.h>
#include <stdio.h>

enum odd_or_even{ ODD, EVEN };

unsigned int absolute_value( int x );

unsigned int sum_of_squares( int numbers[], int number_of_numbers );

int find_biggest( int numbers[], int number_of_numbers, enum odd_or_even o_o_e);
